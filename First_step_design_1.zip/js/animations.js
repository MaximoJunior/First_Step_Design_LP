
// window.onload = function (){
//     console.log("Junior let go");
//     window.addEventListener("scroll", animationScroll);
    
// }

// window.onload = function() {
//     console.log("Junior is commit");
// }

// function animationScroll(){
//     var supportPageOffset = window.pageXOffset !== undefined;
//     var isCSS1Compat = ((document.compatMode || "") === "CSS1Compat");
//     var y = supportPageOffset ? window.pageYOffset : isCSS1Compat ? document.documentElement.scrollTop : document.body.scrollTop;
//     //console.log(y);
// }

// //console.log("Santos")


    